# Notebook plan: Advanced IDH-G resistance analytics

## Phase 1 — Data audit

- Download GEO metadata.
- Inventory sample IDs.
- Map patient IDs and longitudinal relationships.
- Identify tumor subtype: astrocytoma vs oligodendroglioma.
- Identify grade and recurrence/progression fields.
- Document missingness.

## Phase 2 — Single-cell QC

For snRNA-seq:
- genes per nucleus
- UMIs
- mitochondrial percentage
- doublet indicators
- low-quality nuclei removal

For methylation:
- CpG coverage
- missingness
- conversion/quality metrics where supplied
- coverage by genomic region

Do not invent QC thresholds; record the thresholds used and perform sensitivity analysis.

## Phase 3 — Cell-state analysis

Use the paper's cell-state annotations/gene sets where available.

Calculate:
- stem-like score
- differentiated score
- proliferative/cell-cycle score

Then compare earlier vs recurrent samples within patient.

## Phase 4 — Methylation analysis

Calculate:
- global methylation
- promoter methylation
- CpG-island methylation
- G-CIMP-related features
- differential methylation between progression groups

Prioritize PRC2-associated targets and regions highlighted by the paper.

## Phase 5 — Multi-omic integration

Match cell/sample identifiers between:
- RNA
- methylation
- genotype

For each matched unit calculate:
- methylation loss
- stemness
- differentiation
- cell-cycle activity

Then model associations.

## Phase 6 — Evolution

Reconstruct or import the study's high-resolution lineage/phylogenetic representation where possible.

Quantify:
- state heritability
- transition frequency
- transition direction
- stem-like retention
- differentiation probability

## Phase 7 — Resistance hypothesis generation

Generate a ranked *research hypothesis table*, not a treatment recommendation:

| Pattern | Evidence | Interpretation | Follow-up |
|---|---|---|---|
| methylation loss + stem-like enrichment | association | candidate progression mechanism | perturbation experiment |
| PRC2 target hypomethylation | DMR/DE relationship | possible regulatory mechanism | CRISPR/epigenetic perturbation |
| stem-like state persistence after recurrence | longitudinal | possible plasticity | functional validation |

## Phase 8 — Validation

Avoid cell-level train/test leakage.

Preferred validation:
- leave-one-patient-out
- patient-level bootstrap
- external cohort validation

A model that predicts individual patient resistance should only be considered after independent clinical validation.
