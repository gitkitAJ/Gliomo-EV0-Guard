# Report outputs

Expected outputs:

- evolution_pressure_timepoint.png
- methylation_vs_stem_like.png
- patient_trajectories.png
- mixed_effects_summary.txt
- sample_level_summary.csv
- correlations.csv

For the final portfolio report, include:

1. Problem statement
2. Dataset provenance
3. Biological hypothesis
4. Data engineering
5. QC
6. Exploratory analysis
7. Longitudinal analysis
8. Multi-omics integration
9. Statistical modeling
10. Limitations
11. Resistance hypotheses
12. Validation strategy
13. Ethical/clinical limitations
